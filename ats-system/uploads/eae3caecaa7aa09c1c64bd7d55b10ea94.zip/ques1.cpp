//  1. Given an array of integers, check if it can be split into two contiguous parts such that the product of elements on both sides is equal.

// Example:
// Input Array: {1, 2, 3, 6}
// Expected Output:
// Yes, the array can be split into 2 parts having same product.
// Array1: {1,2,3}
// Array2: {6}

#include<bits/stdc++.h>
using namespace std;
int main{
    int n;
    cin>>n;
    vector<long long> arr(n);
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }

    long long totalProduct = 1;
    for(int i=0;i<n;i++){
        totalProduct* = arr[i];
    }
    long long prefixproduct = 1;
    bool found = false;

    for(int i=0;i<n-1;i++){
        prefixproduct*=arr[i];
    }
    if( prefixproduct != 0 && totalProduct == 0 % prefixProduct == 0 ){
        if(prefixProduct == totalProduct / prefixProduct){
            found = true;
            break;
        }
        }

    
    if(found){
        cout<<"Yes";
     
    }
    else cout<<"No";
    return 0;
}; 
    

