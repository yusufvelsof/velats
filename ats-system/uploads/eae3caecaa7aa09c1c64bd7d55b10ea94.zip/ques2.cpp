//  2. Find the pair of numbers whose sum is closest to a given target.

// Example:
// Input: arr = [10, 22, 28, 29, 30, 40], target = 54
// Output: (22, 30)
// Explanation: Pair (22, 30) has sum 52, closest to 54.
#include<bits/stdc++.h>
using namespace std;
int main{
    int target;
    int arr[n];
    cout<<"Enter the array";
    cin>>target;
    for(int i=0;i<n;i++){
       cin>>arr[i];
    }
    for(int i=0;i<n;i++){
        for(int j=i+1;j<n;j++){
            if(arr[i]+arr[j] == target){
                cout<<(arr[i],arr[j]);
            }
        }
    }
   return 0; 
}