// . Given an array of numbers and a positive integer 'n', find the nth most frequently occurring element in the given array.
// (If more than one element has the same nth frequency, you may print any one of them.)
// Example:
// Input array: {1,2,2,2,4,4,4,4,5,5,5,5,5,7,7,8,8,8,8}
// If n = 1 → Output: 5

// If n = 2 → Output: 4 or 8

// If n = 3 → Output: 4 or 8

// If n = 4 → Output: 2 
#include<bits.stdc++.h>
using namespace std;

int  nthFrequent(vector<int>&arr,int n){
    unordered_map<int,int>freq;
    for(int i=0;i<freq;i++){
        freq[num]++;
        vector<pair<int,int>>vec;
        for(auto it:freq){
            vector.push_back(it.second,it.first);
            sort(vec.begin(),vec.end().greater<pair<int,int>>());
            if(n>vec.size())
            return -1;
        return vec[n-1].second;

        }
    }
}
int main{
    int size;
    cin>>size;
    vector<int>arr(size);
    
    for(int i=0;i<size;i++){
        cin>>arr[i];
    
    }
    int n;
    cin>>n;
    int result = nthFrequent(arr,n);

    if(result == -1)
{
    cout<<"NO";
    else cout<<result;
    return 0;
}
} 