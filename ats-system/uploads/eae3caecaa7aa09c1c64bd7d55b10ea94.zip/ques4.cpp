//  4. Input: n rows
// Print numbers in increasing order where each number is the smallest prime factor of its position.
// Example:
// If n = 6, Output:

// 1
// 2 3
// 2 5 2
// 7 2 3 2
// 11 2 13 2 3
// 2 17 2 19 2 3
#include<iostream.h>
using namespace std;
int main{
    vector<int>v(n);
    cout<<"Enter the number of rows";
    cin>>n;
    for(int i=0;i<n;i++){
        for(j=i;j<n-1;j++){
           cout<< v[i];
        }
    }
    return 0;
}