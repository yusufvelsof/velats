-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 13, 2021 at 04:40 AM
-- Server version: 5.7.9
-- PHP Version: 7.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blogs`
--

-- --------------------------------------------------------

--
-- Table structure for table `blogs_categories`
--

DROP TABLE IF EXISTS `blogs_categories`;
CREATE TABLE IF NOT EXISTS `blogs_categories` (
  `bc_category_id` int(10) NOT NULL AUTO_INCREMENT,
  `bc_category_name` varchar(100) NOT NULL,
  `bc_parent_id` int(11) NOT NULL,
  `bc_category_status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `bc_date_added` datetime NOT NULL,
  `bc_created_by` int(11) NOT NULL,
  `bc_date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `bc_modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`bc_category_id`),
  KEY `INDEX_CATEGORY_STATUS` (`bc_category_status`),
  KEY `INDEX_PARENT_ID` (`bc_parent_id`),
  KEY `INDEX_CATEGORIES_CREATED_BY` (`bc_created_by`),
  KEY `INDEX_CATEGORY_MODIFIED_BY` (`bc_modified_by`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blogs_categories`
--

INSERT INTO `blogs_categories` (`bc_category_id`, `bc_category_name`, `bc_parent_id`, `bc_category_status`, `bc_date_added`, `bc_created_by`, `bc_date_modified`, `bc_modified_by`) VALUES
(1, 'Software', 0, 'Active', '2021-03-10 14:54:28', 1, '2021-03-13 08:44:45', NULL),
(2, 'Hardware', 0, 'Active', '2021-03-10 14:54:28', 1, '2021-03-13 08:44:45', NULL),
(3, 'Networking', 0, 'Active', '2021-03-10 14:54:28', 1, '2021-03-13 08:44:45', NULL),
(4, 'Windows Application', 1, 'Active', '2021-03-10 14:54:28', 1, '2021-03-13 08:44:45', NULL),
(5, 'Linux Application', 1, 'Active', '2021-03-10 14:54:28', 1, '2021-03-13 08:44:45', NULL),
(6, 'Monitor', 2, 'Active', '2021-03-10 14:54:28', 1, '2021-03-13 08:44:45', NULL),
(7, 'Hard Disk Drive', 2, 'Active', '2021-03-10 14:54:28', 1, '2021-03-13 08:44:45', NULL),
(8, 'Peripheral Devices', 2, 'Active', '2021-03-10 14:54:28', 1, '2021-03-13 08:44:45', NULL),
(9, 'Networking Devices', 2, 'Active', '2021-03-10 14:54:28', 1, '2021-03-13 08:44:45', NULL),
(10, 'Hacking', 3, 'Active', '2021-03-10 14:54:28', 1, '2021-03-13 08:44:45', NULL),
(11, 'LAN', 3, 'Active', '2021-03-10 14:54:28', 1, '2021-03-13 08:44:45', NULL),
(12, 'MAN', 3, 'Active', '2021-03-10 14:54:28', 1, '2021-03-13 08:44:45', NULL),
(13, 'WAN', 3, 'Active', '2021-03-10 14:54:28', 1, '2021-03-13 08:44:45', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `blogs_comments`
--

DROP TABLE IF EXISTS `blogs_comments`;
CREATE TABLE IF NOT EXISTS `blogs_comments` (
  `bc_comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `bc_blog_id` int(11) NOT NULL,
  `bc_user_name` varchar(50) NOT NULL,
  `bc_comment` text NOT NULL,
  `bc_date_added` datetime NOT NULL,
  `bc_date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`bc_comment_id`),
  KEY `INDEX_COMMENT_BLOG_ID` (`bc_blog_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blogs_comments`
--

INSERT INTO `blogs_comments` (`bc_comment_id`, `bc_blog_id`, `bc_user_name`, `bc_comment`, `bc_date_added`, `bc_date_modified`) VALUES
(1, 2, 'Harsh', 'The term "ethical hacker" has received criticism at times from people who say that there is no such thing as an "ethical" hacker. Hacking is hacking, no matter how you look at it and those who do the hacking are commonly referred to as computer criminals or cyber criminals.', '2020-06-13 19:29:14', '2020-06-13 14:07:37'),
(2, 2, 'Manish', 'However, the work that ethical hackers do for organizations has helped improve system security and can be said to be quite effective and successful. Individuals interested in becoming an ethical hacker can work towards a certification to become a Certified Ethical Hacker, or CEH. This certification is provided by the International Council of E-Commerce Consultants (EC-Council). The exam itself costs about $500 to take and consists of 125 multiple-choice questions in version 8 of the test (version 7 consisted of 150 multiple-choice questions).', '2020-09-13 19:40:59', '2021-03-13 04:38:55'),
(3, 12, 'Harsh', 'The blog was absolutely fantastic! A lot of great information which can be helpful in some or the other way. Keep updating the blog, looking forward to more content...Great job, keep it up.\r\n', '2020-12-14 11:22:18', '2021-03-13 04:38:45'),
(4, 3, 'Rishi', 'Thanks for the excellent information about SEO importance. SEO is a really important factor for any website. We should properly optimize websites for better indexing and website rankings. That is the only way to accomplish the goals of your website.', '2021-02-14 11:22:41', '2021-03-13 04:38:29');

-- --------------------------------------------------------

--
-- Table structure for table `blogs_details`
--

DROP TABLE IF EXISTS `blogs_details`;
CREATE TABLE IF NOT EXISTS `blogs_details` (
  `bd_blog_id` int(11) NOT NULL AUTO_INCREMENT,
  `bd_user_id` int(11) NOT NULL,
  `bd_category_id` int(11) NOT NULL,
  `bd_blog_title` varchar(100) NOT NULL,
  `bd_blog_description` text NOT NULL,
  `bd_blog_status` enum('Published','Draft') NOT NULL DEFAULT 'Published',
  `bd_date_added` datetime NOT NULL,
  `bd_date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `bd_modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`bd_blog_id`),
  KEY `INDEX_BLOG_MODIFIED_BY` (`bd_modified_by`),
  KEY `INDEX_BLOG_STATUS` (`bd_blog_status`),
  KEY `INDEX_BLOG_CATEGORY_ID` (`bd_category_id`),
  KEY `INDEX_BLOG_USER_ID` (`bd_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blogs_details`
--

INSERT INTO `blogs_details` (`bd_blog_id`, `bd_user_id`, `bd_category_id`, `bd_blog_title`, `bd_blog_description`, `bd_blog_status`, `bd_date_added`, `bd_date_modified`, `bd_modified_by`) VALUES
(1, 1, 10, 'Ethical Hacking', 'An ethical hacker is a computer and networking expert who systematically attempts to penetrate a computer system or network on behalf of its owners for the purpose of finding security vulnerabilities that a malicious hacker could potentially exploit.\r\n\r\nEthical hacking and ethical hacker are terms used to describe hacking performed by a company or individual to help identify potential threats on a computer or network. An ethical hacker attempts to bypass system security and search for any weak points that could be exploited by malicious hackers. This information is then used by the organization to improve the system security, in an effort to minimize or eliminate any potential attacks.\r\n\r\nWhat constitutes ethical hacking?\r\n\r\nFor hacking to be deemed ethical, the hacker must obey the following rules:\r\n1. Expressed (often written) permission to probe the network and attempt to identify potential security risks.\r\n2. You respect the individual''s or company''s privacy.\r\n3. You close out your work, not leaving anything open for you or someone else to exploit at a later time.\r\n4. You let the software developer or hardware manufacturer know of any security vulnerabilities you locate in their software or hardware, if not already known by the company.', 'Published', '2019-06-13 17:25:52', '2020-02-10 13:46:09', 1),
(2, 1, 4, 'Another Ethical Hacking', 'An ethical hacker is a computer and networking expert who systematically attempts to penetrate a computer system or network on behalf of its owners for the purpose of finding security vulnerabilities that a malicious hacker could potentially exploit.\r\n\r\nEthical hacking and ethical hacker are terms used to describe hacking performed by a company or individual to help identify potential threats on a computer or network. An ethical hacker attempts to bypass system security and search for any weak points that could be exploited by malicious hackers. This information is then used by the organization to improve the system security, in an effort to minimize or eliminate any potential attacks.\r\n\r\nWhat constitutes ethical hacking?\r\n\r\nFor hacking to be deemed ethical, the hacker must obey the following rules:\r\n1. Expressed (often written) permission to probe the network and attempt to identify potential security risks.\r\n2. You respect the individual''s or company''s privacy.\r\n3. You close out your work, not leaving anything open for you or someone else to exploit at a later time.\r\n4. You let the software developer or hardware manufacturer know of any security vulnerabilities you locate in their software or hardware, if not already known by the company.', 'Published', '2019-06-13 17:26:22', '2020-02-10 13:46:16', 2),
(3, 1, 5, 'Why you should use SEO', 'When a visitor comes online for the first time, he.', 'Draft', '2019-06-14 11:21:43', '2020-02-10 13:46:26', 2),
(5, 1, 7, 'Is your eCommerce Business missing out on these 5 services?', 'When a visitor comes online for the first time, he/she would want to consult some assistant that can help them around. After all, no customer would click on the CTA button without having proper knowledge about the store and its products. Having that little chatbot placed in the corner where the visitors would be able to see and have access to any kind of help from the customer care department would be a service that would be missing but is surely a trend in Social Media Optimization in the year 2018.', 'Published', '2019-09-02 14:06:06', '2020-02-10 13:46:33', 1),
(6, 1, 7, '8 SEO strategies to keep on radar in 2018', 'In today’s rapidly shifting world, the SEO techniques can change on a dime and you might not be aware of the same. If you take a closer look at the eCommerce SEO strategies, you’ll see that they only become effective when all the aspects are put together in the best measures and interests of the consumer as well as the aim to make the website’s quality better. With the SEO algorithms changing every now and then, it is exceptionally important to stay ahead of the time and updated with what’s going to happen next.', 'Published', '2019-09-02 14:06:06', '2020-02-10 13:46:38', 2),
(7, 1, 8, ' Elements of eCommerce web designing that’ll be the game changer in 2018', 'No matter the year and the time, this is one aspect that the will remain unaltered when it comes to web design. The user interface should appeal the site visitors. However, with time the buying behavior of the customers change and so does the need to optimize the website. Since we are on the verge of welcoming a new year, it is high time to discuss the design trends that will follow in the year 2018. Gear yourself with some of the trends listed below and stand apart from the crowd.', 'Published', '2019-09-02 14:06:06', '2020-02-10 13:46:44', 1),
(8, 1, 7, '8 SEO strategies to keep on radar in 2018', 'In today’s rapidly shifting world, the SEO techniques can change on a dime and you might not be aware of the same. If you take a closer look at the eCommerce SEO strategies, you’ll see that they only become effective when all the aspects are put together in the best measures and interests of the consumer as well as the aim to make the website’s quality better. With the SEO algorithms changing every now and then, it is exceptionally important to stay ahead of the time and updated with what’s going to happen next.', 'Published', '2019-09-02 14:06:06', '2020-02-10 13:46:50', 2),
(9, 1, 4, '6 Things to know about Online Reputation Management', 'Now, when the majority of the online stores are involved in selling their products on their website or mobile app or even on online marketplaces, they indulge in advertising it on the various social media platforms. Well, these days the very first place where the angry and agitated customers post a bad remark is on Facebook, Twitter or even Instagram. Hence, you need a fix that would help you save your brand image in these cases.', 'Published', '2019-09-02 14:06:06', '2020-02-10 13:46:56', 1),
(10, 1, 5, '7 Elements of eCommerce web designing that’ll be the game changer in 2018', 'No matter the year and the time, this is one aspect that the will remain unaltered when it comes to web design. The user interface should appeal the site visitors. However, with time the buying behavior of the customers change and so does the need to optimize the website. Since we are on the verge of welcoming a new year, it is high time to discuss the design trends that will follow in the year 2018. Gear yourself with some of the trends listed below and stand apart from the crowd.', 'Published', '2019-09-02 14:06:06', '2020-02-10 13:47:08', 1),
(11, 1, 10, '7 SEO mistakes to avoid in 2018', 'Search Engine Optimization (SEO) still counts to be the most effective way to drive traffic to your website only if you are putting in the strategies right. However, sometimes SEO for eCommerce businesses make mistakes that cause them a lot of damage. Because of the internet boom, it has become quite difficult for an eCommerce business to survive without having SEO services because if they don’t keep this in focus, their ranking in the search engine results will go down.', 'Published', '2020-02-02 11:00:15', '2021-02-02 05:30:15', 1),
(12, 1, 4, 'Is it wise to Hire a Mobile Development Agency?', 'The role of developing a mobile app for ecommerce picked up the pace when the industry saw the upsurge in the smartphones’ popularity. In today’s times, mobile development has become more of a necessity rather than an option. It all started with the overpowering of mobile devices on computers for the sole reason of accessing the internet. In today’s time, we need a mobile app for every possible need. From accessing the social media platforms to banking, shopping, booking tickets, ordering food, and so much more. Hence, this has been influencing almost every industry to have their own Mobile Application.', 'Published', '2020-09-02 14:06:06', '2021-03-13 04:39:37', 1),
(13, 1, 7, 'Trends in Social Media Optimization to watch out for in 2018', 'We are all past those days when we just created a page on Facebook for business purposes and consider it to be done. With all the new social platforms, processes, and ways to advertise that have made the whole thing a lot complex. So, as we are coming to an end of 2017 or you can say going to witness a new year in a matter of a month, there are some of the latest trends in social media optimization that you should be on your radar.', 'Published', '2020-09-02 14:06:06', '2020-10-10 13:47:20', 1),
(14, 1, 6, '5 Mobile App Trends You Can’t Ignore in 2018', 'Can you live without your mobile phone for a day? You might or probably you might not. The chances are more that you would go insane when you don’t find your phone. Smartphones have become an inseparable part of our daily lives. Starting from the morning alarm to the staying in constant touch with family & friends, getting your hands on the latest news or even urgent mails exchange and more, the list of what a smartphone can do is getting longer year by year.', 'Published', '2020-12-02 14:06:06', '2021-02-10 13:47:28', 1),
(15, 1, 7, '8 SEO strategies to keep on radar in 2017', 'In today’s rapidly shifting world, the SEO techniques can change on a dime and you might not be aware of the same. If you take a closer look at the eCommerce SEO strategies, you’ll see that they only become effective when all the aspects are put together in the best measures and interests of the consumer as well as the aim to make the website’s quality better. With the SEO algorithms changing every now and then, it is exceptionally important to stay ahead of the time and updated with what’s going to happen next.', 'Published', '2021-02-02 14:06:06', '2021-02-10 13:47:32', 1),
(16, 1, 7, 'Why should eCommerce blogging be a part of Your SEO strategy?', 'The idea of having a blog for every eCommerce website is that it brings traffic to the site. You want traffic to your site and blogging is one of the many aspects which can do that for you. This is no secret that the blog section or the blogs themselves have a lot to do when it comes to increasing the engagement of the site visitors. But, that’s not it!! There are other benefits as well of having a blog at every eCommerce site.', 'Published', '2021-03-02 14:06:06', '2021-03-10 13:47:37', 1);

-- --------------------------------------------------------

--
-- Table structure for table `blogs_users`
--

DROP TABLE IF EXISTS `blogs_users`;
CREATE TABLE IF NOT EXISTS `blogs_users` (
  `bu_user_id` int(11) NOT NULL AUTO_INCREMENT,
  `bu_first_name` varchar(50) NOT NULL,
  `bu_last_name` varchar(50) NOT NULL,
  `bu_email` varchar(50) NOT NULL,
  `bu_password` varchar(100) NOT NULL,
  `bu_status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `bu_date_added` datetime NOT NULL,
  `bu_created_by` int(11) DEFAULT NULL,
  `bu_date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `bu_modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`bu_user_id`),
  UNIQUE KEY `UNIQUE_USER_EMAIL` (`bu_email`),
  KEY `INDEX_USER_STATUS` (`bu_status`),
  KEY `INDEX_USER_MODIFIED_BY` (`bu_modified_by`),
  KEY `INDEX_USER_CREATED_BY` (`bu_created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blogs_users`
--

INSERT INTO `blogs_users` (`bu_user_id`, `bu_first_name`, `bu_last_name`, `bu_email`, `bu_password`, `bu_status`, `bu_date_added`, `bu_created_by`, `bu_date_modified`, `bu_modified_by`) VALUES
(1, 'Harsh', 'Agarwal', 'hagarwal@velsof.com', 'e10adc3949ba59abbe56e057f20f883e', 'Active', '2021-02-13 14:45:56', NULL, '2021-02-13 09:15:56', NULL),
(2, 'Arjun', 'Teotia', 'ateotia@velsof.com', 'e10adc3949ba59abbe56e057f20f883e', 'Inactive', '2021-03-13 12:45:56', NULL, '2021-03-13 13:15:56', NULL);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `blogs_categories`
--
ALTER TABLE `blogs_categories`
  ADD CONSTRAINT `blogs_categories_ibfk_3` FOREIGN KEY (`bc_created_by`) REFERENCES `blogs_users` (`bu_user_id`) ON UPDATE NO ACTION,
  ADD CONSTRAINT `blogs_categories_ibfk_4` FOREIGN KEY (`bc_modified_by`) REFERENCES `blogs_users` (`bu_user_id`) ON UPDATE NO ACTION;

--
-- Constraints for table `blogs_comments`
--
ALTER TABLE `blogs_comments`
  ADD CONSTRAINT `blogs_comments_ibfk_1` FOREIGN KEY (`bc_blog_id`) REFERENCES `blogs_details` (`bd_blog_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `blogs_details`
--
ALTER TABLE `blogs_details`
  ADD CONSTRAINT `FK_Blogs_Details_Category_ID` FOREIGN KEY (`bd_category_id`) REFERENCES `blogs_categories` (`bc_category_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_Blogs_Details_Modified_By` FOREIGN KEY (`bd_modified_by`) REFERENCES `blogs_users` (`bu_user_id`) ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_Blogs_Details_User_ID` FOREIGN KEY (`bd_user_id`) REFERENCES `blogs_users` (`bu_user_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `blogs_users`
--
ALTER TABLE `blogs_users`
  ADD CONSTRAINT `blogs_users_ibfk_1` FOREIGN KEY (`bu_modified_by`) REFERENCES `blogs_users` (`bu_user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `blogs_users_ibfk_2` FOREIGN KEY (`bu_created_by`) REFERENCES `blogs_users` (`bu_user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
